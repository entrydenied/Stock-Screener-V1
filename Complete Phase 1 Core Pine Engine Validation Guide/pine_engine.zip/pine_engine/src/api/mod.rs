// API module for Pine Engine
// Defines the gRPC interface for the Pine Engine

use tonic::{transport::Server, Request, Response, Status};
use serde::{Deserialize, Serialize};

// Import the generated protobuf code
pub mod pine_engine {
    tonic::include_proto!("pine_engine");
}

use pine_engine::{
    pine_engine_service_server::{PineEngineService, PineEngineServiceServer},
    ExecuteRequest, ExecuteResponse, Alert, Plot, PlotValue,
};

use crate::parser;
use crate::runtime::data::{OHLCVData, Candle};
use crate::runtime::value::Value;
use chrono::{DateTime, TimeZone, Utc};
use std::collections::HashMap;

// Implementation of the gRPC service
pub struct PineEngineServiceImpl {
    // Add any state needed for the service
}

impl PineEngineServiceImpl {
    pub fn new() -> Self {
        PineEngineServiceImpl {}
    }
}

#[tonic::async_trait]
impl PineEngineService for PineEngineServiceImpl {
    async fn execute(
        &self,
        request: Request<ExecuteRequest>,
    ) -> Result<Response<ExecuteResponse>, Status> {
        let req = request.into_inner();
        
        // Parse the script
        let ast = parser::parse(&req.script)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse script: {}", e)))?;
        
        // Convert the request data to OHLCVData
        let mut data = OHLCVData::with_symbol_and_timeframe(&req.symbol, &req.timeframe);
        
        for candle_data in req.data {
            let timestamp = match DateTime::from_timestamp(candle_data.timestamp, 0) {
                Some(dt) => dt,
                None => return Err(Status::invalid_argument("Invalid timestamp")),
            };
            
            let candle = Candle {
                timestamp,
                open: candle_data.open,
                high: candle_data.high,
                low: candle_data.low,
                close: candle_data.close,
                volume: candle_data.volume,
            };
            
            data.add_candle(candle);
        }
        
        // Execute the script
        let engine = crate::PineEngine::new();
        let result = engine.execute(&ast, &data)
            .map_err(|e| Status::internal(format!("Execution error: {}", e)))?;
        
        // Convert the result to the response format
        let mut alerts = Vec::new();
        for alert_data in result.alerts {
            let title = alert_data.get("title")
                .and_then(|v| match v {
                    Value::String(s) => Some(s.clone()),
                    _ => None,
                })
                .unwrap_or_default();
            
            let message = alert_data.get("message")
                .and_then(|v| match v {
                    Value::String(s) => Some(s.clone()),
                    _ => None,
                })
                .unwrap_or_default();
            
            alerts.push(Alert {
                title,
                message,
            });
        }
        
        let mut plots = Vec::new();
        for (plot_value, plot_params) in result.plots {
            let name = plot_params.get("title")
                .and_then(|v| match v {
                    Value::String(s) => Some(s.clone()),
                    _ => None,
                })
                .unwrap_or_default();
            
            let color = plot_params.get("color")
                .and_then(|v| match v {
                    Value::String(s) => Some(s.clone()),
                    Value::Color(s) => Some(s.clone()),
                    _ => None,
                })
                .unwrap_or_default();
            
            let values = match plot_value {
                Value::Series(series) => {
                    series.iter().map(|v| match v {
                        Value::Float(f) => *f,
                        Value::Integer(i) => *i as f64,
                        _ => 0.0,
                    }).collect()
                },
                _ => Vec::new(),
            };
            
            plots.push(Plot {
                name,
                color,
                values: values.iter().map(|v| PlotValue { value: *v }).collect(),
            });
        }
        
        Ok(Response::new(ExecuteResponse {
            alerts,
            plots,
        }))
    }
}

// Start the gRPC server
pub async fn start_server(addr: &str) -> Result<(), Box<dyn std::error::Error>> {
    let addr = addr.parse()?;
    let service = PineEngineServiceImpl::new();
    
    println!("Starting gRPC server on {}", addr);
    
    Server::builder()
        .add_service(PineEngineServiceServer::new(service))
        .serve(addr)
        .await?;
    
    Ok(())
}

// Proto file definition (to be saved separately)
pub const PROTO_DEFINITION: &str = r#"
syntax = "proto3";

package pine_engine;

service PineEngineService {
  rpc Execute (ExecuteRequest) returns (ExecuteResponse);
}

message ExecuteRequest {
  string script = 1;
  string symbol = 2;
  string timeframe = 3;
  repeated CandleData data = 4;
}

message CandleData {
  int64 timestamp = 1;
  double open = 2;
  double high = 3;
  double low = 4;
  double close = 5;
  double volume = 6;
}

message ExecuteResponse {
  repeated Alert alerts = 1;
  repeated Plot plots = 2;
}

message Alert {
  string title = 1;
  string message = 2;
}

message Plot {
  string name = 1;
  string color = 2;
  repeated PlotValue values = 3;
}

message PlotValue {
  double value = 1;
}
"#;
