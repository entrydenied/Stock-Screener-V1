// Runtime error module
// Defines error types that can occur during runtime execution

use std::fmt;

/// Represents errors that can occur during runtime execution
#[derive(Debug)]
pub enum RuntimeError {
    /// Type error (incompatible types)
    TypeError {
        expected: String,
        found: String,
        message: String,
    },
    /// Variable not found
    VariableNotFound {
        name: String,
    },
    /// Function not found
    FunctionNotFound {
        name: String,
    },
    /// Invalid function arguments
    InvalidArguments {
        function: String,
        message: String,
    },
    /// Index out of bounds
    IndexOutOfBounds {
        index: i64,
        size: usize,
    },
    /// Division by zero
    DivisionByZero,
    /// Unsupported feature
    UnsupportedFeature {
        feature: String,
        message: String,
    },
    /// Data error
    DataError {
        message: String,
    },
    /// Other runtime error
    Other {
        message: String,
    },
}

impl fmt::Display for RuntimeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RuntimeError::TypeError { expected, found, message } => {
                write!(f, "Type error: expected {}, found {}. {}", expected, found, message)
            }
            RuntimeError::VariableNotFound { name } => {
                write!(f, "Variable not found: {}", name)
            }
            RuntimeError::FunctionNotFound { name } => {
                write!(f, "Function not found: {}", name)
            }
            RuntimeError::InvalidArguments { function, message } => {
                write!(f, "Invalid arguments for function {}: {}", function, message)
            }
            RuntimeError::IndexOutOfBounds { index, size } => {
                write!(f, "Index out of bounds: {} (size: {})", index, size)
            }
            RuntimeError::DivisionByZero => {
                write!(f, "Division by zero")
            }
            RuntimeError::UnsupportedFeature { feature, message } => {
                write!(f, "Unsupported feature '{}': {}", feature, message)
            }
            RuntimeError::DataError { message } => {
                write!(f, "Data error: {}", message)
            }
            RuntimeError::Other { message } => {
                write!(f, "Runtime error: {}", message)
            }
        }
    }
}

impl std::error::Error for RuntimeError {}
