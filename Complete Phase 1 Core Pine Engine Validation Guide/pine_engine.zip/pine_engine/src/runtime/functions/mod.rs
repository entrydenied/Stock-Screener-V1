// Functions module for Pine Script runtime
// Defines the technical analysis functions

pub mod ta;
pub mod math;
pub mod utility;

use super::environment::Environment;

/// Register all technical analysis functions
pub fn register_ta_functions(env: &mut Environment) {
    ta::register_functions(env);
}

/// Register all math functions
pub fn register_math_functions(env: &mut Environment) {
    math::register_functions(env);
}

/// Register all utility functions
pub fn register_utility_functions(env: &mut Environment) {
    utility::register_functions(env);
}
