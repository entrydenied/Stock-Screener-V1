// Runtime module for Pine Script
// Responsible for executing Pine Script AST

pub mod data;
pub mod error;
pub mod execution;
pub mod value;
pub mod environment;
pub mod functions;

use crate::parser::ast::{Script, Statement, Expression};
use data::OHLCVData;
use error::RuntimeError;
use execution::ExecutionResult;
use value::Value;
use environment::Environment;

/// Runtime for executing Pine Script
pub struct Runtime {
    environment: Environment,
}

impl Runtime {
    /// Create a new runtime
    pub fn new() -> Self {
        Runtime {
            environment: Environment::new(),
        }
    }
    
    /// Execute a script with the given input data
    pub fn execute(&mut self, script: &Script, data: &OHLCVData) -> Result<ExecutionResult, RuntimeError> {
        // Register built-in functions
        self.register_built_in_functions();
        
        // Set up the environment with the data
        self.environment.set_data(data);
        
        // Execute declarations
        for declaration in &script.declarations {
            self.execute_declaration(declaration)?;
        }
        
        // Execute statements
        for statement in &script.statements {
            self.execute_statement(statement)?;
        }
        
        // Collect results
        let result = ExecutionResult {
            alerts: self.environment.get_alerts(),
            plots: self.environment.get_plots(),
        };
        
        Ok(result)
    }
    
    /// Register built-in functions in the environment
    fn register_built_in_functions(&mut self) {
        // Register technical analysis functions
        functions::register_ta_functions(&mut self.environment);
        
        // Register other built-in functions
        functions::register_math_functions(&mut self.environment);
        functions::register_utility_functions(&mut self.environment);
    }
    
    /// Execute a declaration
    fn execute_declaration(&mut self, declaration: &crate::parser::ast::Declaration) -> Result<(), RuntimeError> {
        // For now, we just need to handle indicator declarations
        // Other declarations like strategy will be added later
        match declaration {
            crate::parser::ast::Declaration::Indicator { name, parameters } => {
                // Store indicator name and parameters in environment
                self.environment.set_indicator_name(name.clone());
                
                // Process parameters
                for (param_name, param_expr) in parameters {
                    let param_value = self.evaluate_expression(param_expr)?;
                    self.environment.set_indicator_parameter(param_name.clone(), param_value);
                }
                
                Ok(())
            }
            _ => Err(RuntimeError::UnsupportedFeature {
                feature: "Non-indicator declarations".to_string(),
                message: "Only indicator declarations are supported in the MVP".to_string(),
            }),
        }
    }
    
    /// Execute a statement
    fn execute_statement(&mut self, statement: &Statement) -> Result<(), RuntimeError> {
        match statement {
            Statement::Assignment { variable, value } => {
                let evaluated_value = self.evaluate_expression(value)?;
                self.environment.set_variable(variable.clone(), evaluated_value);
                Ok(())
            }
            Statement::Conditional { condition, then_branch, else_branch } => {
                let condition_value = self.evaluate_expression(condition)?;
                
                if condition_value.as_bool()? {
                    self.execute_statement(then_branch)?;
                } else if let Some(else_stmt) = else_branch {
                    self.execute_statement(else_stmt)?;
                }
                
                Ok(())
            }
            Statement::Block { statements } => {
                // Create a new scope
                self.environment.push_scope();
                
                // Execute all statements in the block
                for stmt in statements {
                    self.execute_statement(stmt)?;
                }
                
                // Pop the scope
                self.environment.pop_scope();
                
                Ok(())
            }
            Statement::FunctionCall { name, arguments, named_arguments } => {
                // Evaluate all arguments
                let mut evaluated_args = Vec::new();
                for arg in arguments {
                    evaluated_args.push(self.evaluate_expression(arg)?);
                }
                
                // Evaluate named arguments
                let mut evaluated_named_args = std::collections::HashMap::new();
                for (name, arg) in named_arguments {
                    evaluated_named_args.insert(name.clone(), self.evaluate_expression(arg)?);
                }
                
                // Call the function
                self.environment.call_function(name, &evaluated_args, &evaluated_named_args)?;
                
                Ok(())
            }
            Statement::Plot { expression, parameters } => {
                // Evaluate the expression to plot
                let value = self.evaluate_expression(expression)?;
                
                // Evaluate parameters
                let mut evaluated_params = std::collections::HashMap::new();
                for (name, param) in parameters {
                    evaluated_params.insert(name.clone(), self.evaluate_expression(param)?);
                }
                
                // Add to plots
                self.environment.add_plot(value, evaluated_params);
                
                Ok(())
            }
            Statement::PlotShape { expression, parameters } => {
                // Evaluate the expression to plot
                let value = self.evaluate_expression(expression)?;
                
                // Evaluate parameters
                let mut evaluated_params = std::collections::HashMap::new();
                for (name, param) in parameters {
                    evaluated_params.insert(name.clone(), self.evaluate_expression(param)?);
                }
                
                // Add to plot shapes
                self.environment.add_plot_shape(value, evaluated_params);
                
                Ok(())
            }
            Statement::AlertCondition { condition, parameters } => {
                // Evaluate the condition
                let condition_value = self.evaluate_expression(condition)?;
                
                // Evaluate parameters
                let mut evaluated_params = std::collections::HashMap::new();
                for (name, param) in parameters {
                    evaluated_params.insert(name.clone(), self.evaluate_expression(param)?);
                }
                
                // Add to alerts if condition is true
                if condition_value.as_bool()? {
                    self.environment.add_alert(evaluated_params);
                }
                
                Ok(())
            }
        }
    }
    
    /// Evaluate an expression
    fn evaluate_expression(&mut self, expression: &Expression) -> Result<Value, RuntimeError> {
        match expression {
            Expression::Literal(literal) => {
                match literal {
                    crate::parser::ast::Literal::Integer(value) => Ok(Value::Integer(*value)),
                    crate::parser::ast::Literal::Float(value) => Ok(Value::Float(*value)),
                    crate::parser::ast::Literal::Boolean(value) => Ok(Value::Boolean(*value)),
                    crate::parser::ast::Literal::String(value) => Ok(Value::String(value.clone())),
                    crate::parser::ast::Literal::Color(value) => Ok(Value::Color(value.clone())),
                    crate::parser::ast::Literal::Array(values) => {
                        let mut evaluated_values = Vec::new();
                        for value in values {
                            evaluated_values.push(self.evaluate_expression(value)?);
                        }
                        Ok(Value::Array(evaluated_values))
                    }
                }
            }
            Expression::Variable(name) => {
                self.environment.get_variable(name)
            }
            Expression::BinaryOperation { left, operator, right } => {
                let left_value = self.evaluate_expression(left)?;
                let right_value = self.evaluate_expression(right)?;
                
                match operator {
                    crate::parser::ast::BinaryOperator::Add => left_value.add(&right_value),
                    crate::parser::ast::BinaryOperator::Subtract => left_value.subtract(&right_value),
                    crate::parser::ast::BinaryOperator::Multiply => left_value.multiply(&right_value),
                    crate::parser::ast::BinaryOperator::Divide => left_value.divide(&right_value),
                    crate::parser::ast::BinaryOperator::Modulo => left_value.modulo(&right_value),
                    crate::parser::ast::BinaryOperator::Equal => left_value.equal(&right_value),
                    crate::parser::ast::BinaryOperator::NotEqual => left_value.not_equal(&right_value),
                    crate::parser::ast::BinaryOperator::LessThan => left_value.less_than(&right_value),
                    crate::parser::ast::BinaryOperator::LessThanOrEqual => left_value.less_than_or_equal(&right_value),
                    crate::parser::ast::BinaryOperator::GreaterThan => left_value.greater_than(&right_value),
                    crate::parser::ast::BinaryOperator::GreaterThanOrEqual => left_value.greater_than_or_equal(&right_value),
                    crate::parser::ast::BinaryOperator::And => left_value.and(&right_value),
                    crate::parser::ast::BinaryOperator::Or => left_value.or(&right_value),
                }
            }
            Expression::UnaryOperation { operator, operand } => {
                let operand_value = self.evaluate_expression(operand)?;
                
                match operator {
                    crate::parser::ast::UnaryOperator::Negate => operand_value.negate(),
                    crate::parser::ast::UnaryOperator::Not => operand_value.not(),
                }
            }
            Expression::FunctionCall { name, arguments, named_arguments } => {
                // Evaluate all arguments
                let mut evaluated_args = Vec::new();
                for arg in arguments {
                    evaluated_args.push(self.evaluate_expression(arg)?);
                }
                
                // Evaluate named arguments
                let mut evaluated_named_args = std::collections::HashMap::new();
                for (name, arg) in named_arguments {
                    evaluated_named_args.insert(name.clone(), self.evaluate_expression(arg)?);
                }
                
                // Call the function
                self.environment.call_function(name, &evaluated_args, &evaluated_named_args)
            }
            Expression::ArrayAccess { array, index } => {
                let array_value = self.evaluate_expression(array)?;
                let index_value = self.evaluate_expression(index)?;
                
                array_value.get_index(&index_value)
            }
            Expression::TernaryOperation { condition, then_branch, else_branch } => {
                let condition_value = self.evaluate_expression(condition)?;
                
                if condition_value.as_bool()? {
                    self.evaluate_expression(then_branch)
                } else {
                    self.evaluate_expression(else_branch)
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser;
    
    #[test]
    fn test_simple_execution() {
        let script = r#"//@version=5
        indicator('Test', overlay=true)
        a = 1 + 2
        "#;
        
        let ast = parser::parse(script).unwrap();
        let data = OHLCVData::new(); // Empty data for this test
        
        let mut runtime = Runtime::new();
        let result = runtime.execute(&ast, &data);
        
        assert!(result.is_ok());
    }
}
