// Validation module for Pine Engine
// Responsible for validating the Pine Engine against TradingView

pub mod data_fetcher;
pub mod test_harness;
pub mod comparison;

use crate::parser::ast::Script;
use crate::runtime::data::OHLCVData;
use crate::runtime::execution::ExecutionResult;

/// Validate the Pine Engine against TradingView
pub async fn validate(script: &str, symbol: &str, timeframe: &str) -> Result<ValidationResult, ValidationError> {
    // Parse the script
    let ast = crate::parser::parse(script).map_err(|e| ValidationError::ParseError(e.to_string()))?;
    
    // Fetch historical data
    let data = data_fetcher::fetch_data(symbol, timeframe).await?;
    
    // Execute the script with our engine
    let engine_result = execute_with_engine(&ast, &data)?;
    
    // Get TradingView results (this would typically be manual or via API)
    let tv_result = test_harness::get_tradingview_result(script, symbol, timeframe).await?;
    
    // Compare the results
    let comparison_result = comparison::compare_results(&engine_result, &tv_result)?;
    
    Ok(ValidationResult {
        script: script.to_string(),
        symbol: symbol.to_string(),
        timeframe: timeframe.to_string(),
        engine_result,
        tv_result,
        comparison_result,
    })
}

/// Execute a script with our Pine Engine
fn execute_with_engine(script: &Script, data: &OHLCVData) -> Result<ExecutionResult, ValidationError> {
    let engine = crate::PineEngine::new();
    engine.execute(script, data).map_err(|e| ValidationError::RuntimeError(e.to_string()))
}

/// Represents the result of validation
#[derive(Debug)]
pub struct ValidationResult {
    pub script: String,
    pub symbol: String,
    pub timeframe: String,
    pub engine_result: ExecutionResult,
    pub tv_result: TradingViewResult,
    pub comparison_result: ComparisonResult,
}

/// Represents a result from TradingView
#[derive(Debug, Clone)]
pub struct TradingViewResult {
    pub alerts: Vec<TradingViewAlert>,
    pub plots: Vec<TradingViewPlot>,
}

/// Represents an alert from TradingView
#[derive(Debug, Clone)]
pub struct TradingViewAlert {
    pub timestamp: i64,
    pub title: String,
    pub message: String,
}

/// Represents a plot from TradingView
#[derive(Debug, Clone)]
pub struct TradingViewPlot {
    pub name: String,
    pub values: Vec<f64>,
    pub color: String,
}

/// Represents the result of comparing our engine with TradingView
#[derive(Debug)]
pub struct ComparisonResult {
    pub alert_match_percentage: f64,
    pub plot_match_percentage: f64,
    pub mismatches: Vec<Mismatch>,
}

/// Represents a mismatch between our engine and TradingView
#[derive(Debug)]
pub enum Mismatch {
    AlertCount {
        engine_count: usize,
        tv_count: usize,
    },
    AlertMismatch {
        index: usize,
        engine_alert: String,
        tv_alert: String,
    },
    PlotCount {
        engine_count: usize,
        tv_count: usize,
    },
    PlotValueMismatch {
        plot_name: String,
        index: usize,
        engine_value: f64,
        tv_value: f64,
        difference: f64,
    },
}

/// Represents errors that can occur during validation
#[derive(Debug, thiserror::Error)]
pub enum ValidationError {
    #[error("Parse error: {0}")]
    ParseError(String),
    
    #[error("Runtime error: {0}")]
    RuntimeError(String),
    
    #[error("Data fetching error: {0}")]
    DataFetchingError(String),
    
    #[error("TradingView API error: {0}")]
    TradingViewApiError(String),
    
    #[error("Comparison error: {0}")]
    ComparisonError(String),
}
